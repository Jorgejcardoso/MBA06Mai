# Disciplina: Big Data Analytics com R
# 
# Construir an�lises de dados simples utilizando R

####################################
# Manipulando arquivos e pastas
####################################

# Qual � a pasta de trabalho atual? 
getwd()

# Podemos alterar a pasta de trabalho a qualquer momento.
setwd("D:/Dados")
getwd()

# Perceba que o separador � diferente do habitual do Windows, pois a 
# barra (�\�) � um comando especial da linguagem.
# Caso queira manter o padr�o do Windows, basta usar duas barras.
setwd("D:\\Dados")

# A fun��o file.path() cria o caminho no formato apropriado e pode 
# ser usada para cria��o de caminhos de forma din�mica durante a execu��o de um script.
caminho = file.path("C:","pasta_1", "pasta_2","meu_arquivo.txt")

# Lista arquivos e pastas.
list.files()
# Listar pastas e subpastas.
list.dirs()

# Verificando a exist�ncia de um arquivo.
file.exists("teste.txt")
file.exists("teste1.txt")

# Removendo arquivo
file.remove("teste.txt")
file.exists("teste.txt")

# Criando e removendo pastas
dir.create("Nova Pasta")
list.dirs()
file.remove("Nova Pasta")
list.dirs()

# Podemos tamb�m usar comandos do SO diretamente.
shell("md teste")

####################################
# Formatos de arquivos pr�prios do R
# RData ou rda: salva um ou v�rios objetos da �rea de trabalho. 
#               Espera pelo mesmo nome ao ser carregado.
# rds: salva apenas um objeto. Pode ser carregado com nome diferente.
####################################

# Manipulando RData e rda
mtcars <- mtcars

# Salvando como RData
save(mtcars, file="mtcars.RData")
rm(mtcars)
ls()

# Carregando o arquivo
load(file = "mtcars.RData")
ls()

# Salvando como rds
saveRDS(mtcars, file="mtcars.rds")
rm(mtcars)

# carregando o objeto com nome diferente
dados <- readRDS("mtcars.rds")
ls()

####################################
# Dados e o R
# Para analisarmos dados precisamos carregar os mesmos para process�-los na linguagem R.
# Os dados podem estar em diversos formatos de texto, exemplos comuns:
#               CSV (Comma Separated Values);
#               JSON (JavaScript Object Notation);
#               XML (Extensible Markup Language). 
####################################

####################################
# Lendo dados em CSV
####################################

# Lendo um CSV
auto <- read.csv("auto-mpg.csv", header=TRUE, sep=",")

# Verificando o resultado:
names(auto)

# Vamos tentar importar o arquivo "auto-mpg-noheader.csv". 
# Veremos que o R definir� um cabe�alho ap�s a importa��o.
auto <- read.csv("auto-mpg-noheader.csv", header=FALSE)
head(auto,2)

# Agora importando de outra forma.
# Neste caso o R usa os dados da primeira observa��o como cabe�alho.
auto <- read.csv("auto-mpg-noheader.csv")
head(auto)

# Usando o par�metro col.names para especificar nomes para as colunas.
auto <- read.csv("auto-mpg-noheader.csv", header=FALSE, col.names = c("No", "mpg", "cyl", "dis","hp", "wt", "acc", "year", "car_name"))
head(auto)

# Valores ausentes

# Colocando o R para considerar blanks como NAs em atributos categ�ricos e vari�veis do tipo texto.
nome_dataframe <- read.csv("nome_csv.csv", na.strings="")

# Coer��o for�ada
dados <- read.csv("Dados/PETR4_VALE5.csv", colClasses=c('myDate','numeric','numeric'), header=TRUE, sep=";", dec=",")

####################################
# Conhecendo o objeto factors
####################################

# Criando um vetor.
apple_colors <- c('green','green','yellow','red','red','red','green')

# Criando um objeto do tipo factor.
factor_apple <- factor(apple_colors)

# Apresentando o objeto criado.
print(factor_apple)
print(nlevels(factor_apple))

#Contabilizando as ocorr�ncias
table(factor_apple)

####################################
# Lendo dados diretamente de websites
####################################

dat <- read.csv("http://www.exploredata.net/ftp/WHO.csv")


####################################
# Lendo dados em XML
####################################

# Instalando pacotes.
install.packages("XML")

# Carregando o pacote.
library(XML)

# Inicializando.
url <- "http://www.w3schools.com/xml/cd_catalog.xml"

# Fazendo o "parsing" do arquivo e pegando o root node.
xmldoc <- xmlParse(url)
rootNode <- xmlRoot(xmldoc)
rootNode[1]

# Extraindo os dados do XML. 
# Usamos uma fun��o que varre iterativamente todos os filhos do root node e armazena em uma matriz. 
data <- xmlSApply(rootNode, function(x) xmlSApply(x, xmlValue))

# Conventendo em data frame.
catalogo.cd <- data.frame(t(data),row.names=NULL)

# Verificando os resultados.
head(catalogo.cd)

####################################
# Lendo dados em JSON
####################################

# Instalando pacotes.
install.packages("jsonlite")

# Carregando o pacote.
library(jsonlite)

# Carregando dados dos arquivos JSON.
dat.1 <- fromJSON("students.json")
dat.2 <- fromJSON("student-courses.json")

# Carregando um arquivo JSON da web.
url <- "http://finance.yahoo.com/webservice/v1/symbols/allcurrencies/quote?format=json"
jsonDoc <- fromJSON(url)

# Extraindo dados para os data frames.
dat <- jsonDoc$list$resources$resource$fields

# Verificando os resultados.
head(dat)
head(dat.1)
head(dat.2)

